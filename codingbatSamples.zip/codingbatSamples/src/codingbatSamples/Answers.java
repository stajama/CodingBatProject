package codingbatSamples;

public class Answers {
	
	public Answers() {
		
	}
	
	// --- Warmup-1


	// in1020
	public boolean in1020(int a, int b) {
		// Given 2 int values, return true if either of them is in the range 10..20 inclusive.
	 	return a > 9 && a < 21 || b > 9 && b < 21;
	}

	// sumDouble
	public int sumDouble(int a, int b) {
		// Given two int values, return their sum. Unless the two values are the same, then
		// return double their sum.
		if (a == b){
			return (a + b) * 2;
		} else {
			return a + b;
		}
	}

	// icyHot
	public boolean icyHot(int temp1, int temp2) {
		/*Given two temperatures, return true if one is less than 0 and the
		 * other is greater than 100.
		 */
		return (temp1 < 0 && temp2 > 100) || (temp2 < 0 && temp1 > 100);
	}

	// frontBack
	public String frontBack(String str) {
		// Given a string, return a new string where the first and last chars have been
		// exchanged.
		if (str == ""){
			return str;
		}
			  
		char first = str.charAt(0);
		char last = str.charAt(str.length() - 1);
		String outString = "";
		for (int i = 0; i < str.length(); i++) {
			if (i == 0) {
				outString = outString + Character.toString(last);
			} else if (i == str.length() - 1) {
				outString = outString + Character.toString(first);
			} else {
				outString = outString + Character.toString(str.charAt(i));	
			}
		}
		return outString;
	}

	// intMax
	public int intMax(int a, int b, int c) {
		/*Given three int values, a b c, return the largest.
		*/
		return Math.max(Math.max(a, b), c);
	}

	// startHi
	public boolean startHi(String str) {
		// Given a string, return true if the string starts with "hi" and false otherwise.

		if (str.length() < 2) {
			return false;
		}
		return str.charAt(0) == 'h' && str.charAt(1) == 'i';
	}

	// diff21
	public int diff21(int n) {
		// Given an int n, return the absolute difference between n and 21, except return 
		// double the absolute difference if n is over 21.
		if (n > 21){
			return Math.abs(n - 21) * 2;
		} else {
			return Math.abs(n - 21);
		}
	}

	// monkeyTrouble
	public boolean monkeyTrouble(boolean aSmile, boolean bSmile) {
		// We have two monkeys, a and b, and the parameters aSmile and bSmile indicate if 
		// each is smiling. We are in trouble if they are both smiling or if neither of them
		// is smiling. Return true if we are in trouble.
		return (aSmile && bSmile) || (!aSmile && !bSmile);
	}

	// or35
	public boolean or35(int n) {
		/*Return true if the given non-negative number is a multiple of 3 or a multiple
		* of 5. Use the % "mod" operator -- see Introduction to Mod 
		*/
		return (n % 3 == 0) || (n % 5 ==0);
	}

	// hasTeen
	public boolean hasTeen(int a, int b, int c) {
		// We'll say that a number is "teen" if it is in the range 13..19 inclusive. Given
		//  3 int values, return true if 1 or more of them are teen.
		return a > 12 && a < 20 || b > 12 && b < 20 || c > 12 && c < 20;
	}

	// in3050
	public boolean in3050(int a, int b) {
		// Given 2 int values, return true if they are both in the range 30..40 inclusive,
		// or they are both in the range 40..50 inclusive.
		return ((a < 41 && a > 29) && (b < 41 && b > 29)) || ((a < 51 && a > 39) && (b < 51 && b > 39));
	}

	// max1020
	public int max1020(int a, int b) { 
	// Given 2 positive int values, return the larger value that is in the range 10..2
	// 0 inclusive, or return 0 if neither is in that range.

		if (a > 9 && a < 21) {
			if (b > 9 && b < 21) {
				return Math.max(a, b);
			} else {
				return a;
			}
		} else if (b > 9 && b < 21) {
			return b;
		} else {
			return 0;
		}
	}

	// missingChar
	public String missingChar(String str, int n) {
		// Given a non-empty string and an int n, return a new string where the char at in
		// dex n has been removed. The value of n will be a valid index of a char in the
		// original string (i.e. n will be in the range 0..str.length()-1 inclusive).

		String outString = "";
		for (int i = 0; i < str.length(); i++) {
			if (!(i == n)) {
			outString = outString + Character.toString(str.charAt(i));
			}
		}
		return outString;
	}

	// startOz
	public String startOz(String str) {
		// Given a string, return a string made of the first 2 chars (if present), however
		// include first char only if it is 'o' and include the second only if it is 'z',
		// so "ozymandias" yields "oz".

		if (str.length() < 1) {
			return "";
		}
		String outString = "";
		if (str.charAt(0) == 'o') {
			outString = outString + "o";
		}
		if (str.length() >= 2) {
			if (str.charAt(1) == 'z') {
				outString = outString + "z";
			}
		}
		return outString;
	}

	// sleepIn
	public boolean sleepIn(boolean weekday, boolean vacation) {
		// The parameter weekday is true if it is a weekday, and the parameter vacation is
		// true if we are on vacation. We sleep in if it is not a weekday or we're on
		// vacation. Return true if we sleep in.
		return !weekday || vacation;
	}

	// stringE
	public boolean stringE(String str) {
		// Return true if the given string contains between 1 and 3 'e' chars.
		int counter = 0;
		for (int i = 0; i < str.length(); i++) {
			if (str.charAt(i) == 'e') {
				counter++;
			}
		}
		return counter > 0 && counter < 4;
	}

	// notString
	public String notString(String str) {
		// Given a string, return a new string where "not " has been added to the front.
		// However, if the string already begins with "not", return the string unchanged.
		// Note: use .equals() to compare 2 strings.
		if (str. length() < 3) {
			return "not " + str;
		}
		if (str.charAt(0) != 'n' && str.charAt(1) != 'o' && str.charAt(2) != 't') {
			return "not " + str;
		} else {
			return str;
		}
	}

	// lastDigit
	public boolean lastDigit(int a, int b) {
		// Given two non-negative int values, return true if they have the same last digit,
		// such as with 27 and 57. Note that the % "mod" operator computes remainders,
		// so 17 % 10 is 7.
		return a % 10 == b % 10;
	}

	// parrotTrouble
	public boolean parrotTrouble(boolean talking, int hour) {
		// We have a loud talking parrot. The "hour" parameter is the current hour time in
		// the range 0..23. We are in trouble if the parrot is talking and the hour is
		// before 7 or after 20. Return true if we are in trouble.

		if (hour > 6 && hour < 21){
			return false;
		} else {
			if (talking) {
				return true;
			}
		}
		return false;
	}

	// endUp
	public String endUp(String str) {
		// Given a string, return a new string where the last 3 chars are now in upper case.
		// If the string has less than 3 chars, uppercase whatever is there. Note that 
		// str.toUpperCase() returns the uppercase version of a string.

		int upper = str.length();
		if (upper < 3) {
			return str.toUpperCase();
		}
		String outString = "";
		for (int i = 0; i < upper; i++) {
			if (upper - i < 4) {
				outString = outString + Character.toString(str.charAt(i)).toUpperCase();
			} else {
				outString = outString + Character.toString(str.charAt(i));
			}
		}
		return outString;
	}

	// close10
	public int close10(int a, int b) {
		// Given 2 int values, return whichever value is nearest to the value 10, or return
		// 0 in the event of a tie. Note that Math.abs(n) returns the absolute value of 
		// a number.

		if (Math.abs(10 - a) == Math.abs(10 - b)) {
			return 0;
		} else {
			int a1 = Math.abs(10 - a);
			int b1 = Math.abs(10 - b);
			if (a1 < b1) {
				return a;
			}
		}
		return b;
	}

	// front22
	public String front22(String str) {
		/*Given a string, take the first 2 chars and return the string with
		* the 2 chars added at both the front and back, so "kitten" yields
		* "kikittenki". If the string length is less than 2, use whatever
		* chars are there.  
		*/
		if (str.length() >= 2) {
			String sample = str.substring(0, 2);
			return sample + str + sample;
		} else {
			return str + str + str;
		}
	}

	// posNeg
	public boolean posNeg(int a, int b, boolean negative) {
		// Given 2 int values, return true if one is negative and one is positive. Except 
		// if the parameter "negative" is true, then return true only if both are negative.

		if (negative) {
			return a < 0 && b < 0;
		} else {
			return (a < 0 || b < 0) && !(a < 0 && b < 0) ;
		}
	}

	// front3
	public String front3(String str) {
		// Given a string, we'll say that the front is the first 3 chars of the string. If
		//  the string length is less than 3, the front is whatever is there. Return a new
		//  string which is 3 copies of the front.

		if (str == "") {
			return str;
		}
		int i = 3;
		String outString = "";
		
		if (str.length() < 3) {
			i = str.length();
		}
		for (int x = 0; x < i; x++) {
			outString = outString + Character.toString(str.charAt(x));
		}
		return outString + outString + outString;
	}

	// backAround
	public String backAround(String str) {
		/*Given a string, take the last char and return a new string with the
		* last char added at the front and back, so "cat" yields "tcatt". The
		* original string will be length 1 or more.
		*/

		char last = str.charAt(str.length() - 1);
			return Character.toString(last) + str + Character.toString(last);
	}

	// everyNth
	public String everyNth(String str, int n) {
		// Given a non-empty string and an int N, return the string made starting with char
		// 0, and then every Nth char of the string. So if N is 3, use char 0, 3, 6, ...
		// and so on. N is 1 or more.

		String outString = "";
		for (int i = 0; i < str.length(); i = i + n) {
			outString = outString + Character.toString(str.charAt(i));
		}
		return outString;
	}

	// loneTeen
	public boolean loneTeen(int a, int b) {
		// We'll say that a number is "teen" if it is in the range 13..19 inclusive. Given
		//  2 int values, return true if one or the other is teen, but not both.
		return ((a > 12 && a < 20) && (b < 13 || b > 19)) || ((b > 12 && b < 20) && (a < 13 || a > 19));
	}

	// nearHundred
	public boolean nearHundred(int n) {
		// Given an int n, return true if it is within 10 of 100 or 200. Note: Math.abs(num)
		// computes the absolute value of a number.
		return (Math.abs(100 - n) <= 10 || Math.abs(200 - n) <= 10);
	}

	// delDel
	public String delDel(String str) {
		// Given a string, if the string "del" appears starting at index 1, return a string
		// where that "del" has been deleted. Otherwise, return the string unchanged.

		if (str.length() < 4) {
			return str;
		}
		if (str.charAt(1) == 'd' && str.charAt(2) == 'e' && str.charAt(3) == 'l') {
			String outString = "";
			for (int i = 0; i < str.length(); i++) {
				if ((i != 1) && (i != 2) && (i != 3)) {
					outString = outString + Character.toString(str.charAt(i));
				}
			}
			return outString;
		}
		return str;
	}

	// makes10
	public boolean makes10(int a, int b) {
		// Given 2 ints, a and b, return true if one if them is 10 or if their sum is 10.
		return (a == 10 || b == 10) || (a + b == 10);
	}

	// mixStart
	public boolean mixStart(String str) {
	// Return true if the given string begins with "mix", except the 'm' can be
	// anything, so "pix", "9ix" .. all count.

		if (str.length() < 3) {
			return false;
		}
		char first = str.charAt(1);
		char second = str.charAt(2);
		return first == 'i' && second == 'x';
	}

	// -------------------------------------------------------------------------------
	
	// --- Warmup-2

	// altPairs
	public String altPairs(String str) {
		/*Given a string, return a string made of the chars at indexes 
		*0,1, 4,5, 8,9 ... so "kittens" yields "kien".
		*/
		String outString = "";
		for (int i = 0; i < str.length(); i++) {
			if (i == 0 || i == 1 || i == 4 || i == 5 || i == 8 || i == 9 || i == 12 || i == 13) {
				outString = outString + str.charAt(i);
			}
		}
		return outString;
	}

	// noTriples
	public boolean noTriples(int[] nums) {
		/*Given an array of ints, we'll say that a triple is a value appearing
		3 times in a row in the array. Return true if the array does not 
		contain any triples.  
		*/
		int last = -1001;
		int counter = 0;
		for (int i = 0; i < nums.length; i++) {
			if (nums[i] == last) {
				counter ++;
				if (counter >= 3) {
					return false;
				}
			} else {
				counter = 1;
				last = nums[i];
			}
		}
		return true;
	}

	// array667
	public int array667(int[] nums) {
		/*Given an array of ints, return the number of times that two 6's are
		next to each other in the array. Also count instances where the second
		"6" is actually a 7.
		*/
		int count = 0;
		boolean turn = false;
		for (int i = 0; i < nums.length - 1; i++) {
			if (nums[i] == 6 && (nums[i + 1] == 6 || nums[i + 1] == 7)) {
				count++;
			}
		}
		return count;
	}

	// arrayFront9
	public boolean arrayFront9(int[] nums) {
		// Given an array of ints, return true if one of the first 4 elements in the array
		//  is a 9. The array length may be less than 4.
		for (int i =0; i < nums.length; i++) {
			if (i < 4 && nums[i] == 9) {
				return true;
			}
		}
		return false;
	}

	// stringMatch
	public int stringMatch(String a, String b) {
	// Given 2 strings, a and b, return the number of the positions where they contain
	// the same length 2 substring. So "xxcaazz" and "xxbaaz" yields 3, since the "xx",
	// "aa", and "az" substrings appear in the same place in both strings.
		int counter = 0;
		int end;
		if (a.length() == b.length()) {
			end = a.length();
		} else if (a.length() > b.length()) {
			end = b.length();
		} else {
			end = a.length();
		}
		for (int i = 0; i < end - 1; i++) {
			if (a.charAt(i) == b.charAt(i) && a.charAt(i + 1) == b.charAt(i + 1)) {
				counter++;
			}
		}
		return counter;
	}

	// stringSplosion
	public String stringSplosion(String str) {
		// Given a non-empty string like "Code" return a string like "CCoCodCode".
		int stop = 1;
		String outString = "";
		for (int i = 0; i < str.length(); i++) {
			for (int x = 0; x < stop; x++){
				outString = outString + Character.toString(str.charAt(x));
			}
			stop = stop + 1;
		}
		return outString;
	}

	// stringYak
	public String stringYak(String str) {
		/*Suppose the string "yak" is unlucky. Given a string, return a version
		where all the "yak" are removed, but the "a" can be any char. The "yak"
		strings will not overlap.
		*/
		String outString = str;
		return outString.replaceAll("y.k", "");
	}

	// doubleX
	public boolean doubleX(String str) { 
		// Given a string, return true if the first instance of "x" in the string is
		// immediately followed by another "x".
		int startIndex = str.indexOf("x");
		if (str.length() - 1 == startIndex) {
			return false;
		}
		return str.charAt(startIndex + 1) == 'x';
	}

	// stringX
	public String stringX(String str) {
		// Given a string, return a version where all the "x" have been removed. Except an
		//  "x" at the very start or end should not be removed.
		String outString = "";
		for (int i = 0; i < str.length(); i++) {
			if ((i == 0 || i == str.length() - 1) || str.charAt(i) != 'x') {
				outString = outString + Character.toString(str.charAt(i));
			}
		}
		return outString;
	}

	// last2
	public int last2(String str) {
		// Given a string, return the count of the number of times that a substring length
		// 2 appears in the string and also as the last 2 chars of the string, so "hixxxhi"
		// yields 1 (we won't count the end substring).
		if (str.length() < 3) {
			return 0;
		}
		char char1 = str.charAt(str.length() - 2);
		char char2 = str.charAt(str.length() - 1);
		int counter = 0;
		for (int i = 0; i < str.length() - 2; i++) {
			if(str.charAt(i) == char1 && str.charAt(i + 1) == char2) {
				counter = counter + 1;
			}
		}
		return counter;
	}

	// stringTimes
	public String stringTimes(String str, int n) {
		// Given a string and a non-negative int n, return a larger string that is n copies
		// of the original string.
		String outString = "";
		for (int i = 0; i < n; i++) {
			outString = outString + str;
		}
		return outString;
	}

	// array123
	public boolean array123(int[] nums) {
		// Given an array of ints, return true if the sequence of numbers 1, 2, 3 appears 
		// in the array somewhere.
		if (nums.length < 3) {
			return false;
		} else if (nums.length == 3) {
			return nums[0] == 1 && nums[1] == 2 && nums[2] == 3;
		}
		for (int i = 0; i <= nums.length - 3; i++) {
			if (nums[i] == 1 && nums[i + 1] == 2 && nums[i + 2] == 3) {
				return true;
			}
		}
		return false;
	}

	// countXX
	public int countXX(String str) {
		// Count the number of "xx" in the given string. We'll say that overlapping is allowed,
		// so "xxx" contains 2 "xx".
		int counter = 0;
		for (int i = 0; i < (str.length() - 1); i++) {
			if (str.charAt(i) == 'x' && str.charAt(i + 1) == 'x') {
				counter++;
			}
		}
		return counter;
	}

	// has271
	public boolean has271(int[] nums) {
		/*Given an array of ints, return true if it contains a 2, 7, 1 pattern:
		a value, followed by the value plus 5, followed by the value minus 1.
		Additionally the 271 counts even if the "1" differs by 2 or less from
		the correct value.  
		*/
		for (int i = 0; i < nums.length - 2; i++) {
			if (nums[i] + 5 == nums[i + 1]) {
				if (Math.abs((nums[i] -  1) - nums[i + 2]) <= 2) {
					return true;
				}
			}
		}
		return false;
	}

	// stringBits
	public String stringBits(String str) {
		// Given a string, return a new string made of every other char starting with the 
		// first, so "Hello" yields "Hlo".
		String outString = "";
		for (int i = 0; i < str.length(); i++) {
			if (i % 2 == 0) {
				outString = outString + Character.toString(str.charAt(i));
			}
		}
		return outString;
	}

	// arrayCount9
	public int arrayCount9(int[] nums) {
		// Given an array of ints, return the number of 9's in the array.
		int counter = 0;
		for (int i = 0; i < nums.length; i++) {
			if (nums[i] == 9) {
				counter++;
			}
		}
		return counter;
	}

	// frontTimes
	public String frontTimes(String str, int n) {
		// Given a string and a non-negative int n, we'll say that the front of the string
		// is the first 3 chars, or whatever is there if the string is less than length 3.
		// Return n copies of the front;
		String out = "";
		if (str.length() < 3) {
			for (int i = 0; i < n; i++){
				out = out + str;
			}
		} else {
			for (int i = 0; i < n; i++){
				out = out + str.substring(0, 3);
			}
		}
		return out;
	}


	
}
